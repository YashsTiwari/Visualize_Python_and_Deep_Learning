from PIL import Image
import os

# Load image
image_path = "img.jpeg"
img = Image.open(image_path)

# Number of rows and columns
rows = 5
cols = 3

# Image dimensions
width, height = img.size

# Patch dimensions
patch_width = width // cols
patch_height = height // rows

# Folder to save patches
output_folder = "patches"
os.makedirs(output_folder, exist_ok=True)

patch_number = 1

# Scan like a convolution filter:
# left -> right, then move to next row
for row in range(rows):
    for col in range(cols):

        # Coordinates of the patch
        left = col * patch_width
        upper = row * patch_height
        right = (col + 1) * patch_width
        lower = (row + 1) * patch_height

        # Crop patch
        patch = img.crop((left, upper, right, lower))

        # Save patch
        patch_name = f"{patch_number}.png"
        patch.save(os.path.join(output_folder, patch_name))

        print(f"Patch {patch_number}: ({left}, {upper}) -> ({right}, {lower})")

        patch_number += 1

print("Done! 15 patches saved.")